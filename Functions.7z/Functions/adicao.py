
def add_values(a, b):
    return a + b
