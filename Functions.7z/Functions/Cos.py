import math

def cosine_of_angle(theta):
  
    return math.cos(theta)
